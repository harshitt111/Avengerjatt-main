# AvengerJatt
clone
bash
npm install
npm run dev
ez pz
